﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("dylan.NET Compiler")> 
<Assembly: AssemblyDescription("Compiler for dylan.NET")> 
<Assembly: AssemblyCompany("Dylan Borg")> 
<Assembly: AssemblyProduct("dylan.NET Compiler")> 
<Assembly: AssemblyCopyright("Copyright ©  2010")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("a5675d38-a7d2-4e02-ad9c-c48cc64b7029")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("9.9.0.0")> 
<Assembly: AssemblyFileVersion("9.9.0.0")> 
